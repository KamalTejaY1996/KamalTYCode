package java.com.employee.service;

import java.com.employee.controller.EmpTax;
import java.com.employee.model.Employee;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
`
public class CalculateTax {

    public double getAnnualTax(Employee employee)
    {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/mm/dd hh:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        int noofdays = dtf.format(now)-employee.getDoj();
        double tax ;
        EmpTax  emptax = new EmpTax();
        if (noofdays >= 365)
             tax = emptax.calculateTaxSlab(12* employee.getSal()+ emptax.getCess(12*employee.getSal()));
        else if (noofdays%30<16)
             tax = emptax.calculateTaxSlab((noofdays/30)* employee.getSal()+ emptax.getCess((noofdays/30)*employee.getSal()));
        else
            tax = emptax.calculateTaxSlab((0.5 + noofdays/30 )* employee.getSal()+ emptax.getCess((0.5 + noofdays/30)*employee.getSal()));
    }
}
