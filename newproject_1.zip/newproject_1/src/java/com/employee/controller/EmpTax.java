package java.com.employee.controller;

import java.com.employee.model.Employee;

public class EmpTax {
    public void addEmp(Employee emp)
    {

    }

    public  double calculateTaxSlab( double salary)
    {
        double tax = 0 ;
        if (salary <= 250000) {
            System.out.println("No Tax for you that your salary is below 2,50,000/-");
            tax = 0.0;
        } else if (salary > 250000 && salary <= 500000) {
            System.out.println(" Your salary is in between 2,50,000/- and 5,00,000/-");
            tax = (salary - 250000) * 0.05;
            System.out.println(" Calculated Tax is : "+tax);
        } else if (salary > 500000 && salary <= 100000) {
            tax = 12500 + (salary - 500000) * 0.1;
            System.out.println(" Employee Tax is : "+tax);
        } else if (salary > 1000000) {
            tax = (salary - 1000000) * 0.2 + 62500;
            System.out.println(" employee Tax is : "+tax);
        }
        return tax;
    }
    public double getCess(double income) {
        double cess = 0.0;
        try {
            if (income > 2500000) {
                cess = income*0.02;
                System.out.println("cess amount is : "+cess);
            }
            return cess;
}
